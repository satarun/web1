import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catlog',
  templateUrl: './catlog.component.html',
  styleUrls: ['./catlog.component.css']
})
export class CatlogComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
